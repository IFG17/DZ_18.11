package com.example.demo;

public class User {
    String password;
    String username;
    int age;
    int id;

    void setUser (int id, int age, String password, String username){
        this.id = id;
        this.age = age;
        this.username = username;
        this.password = password;
    }
    void setUsername (String username){
        this.username = username;
    }

    int getId (){return id;}

    String returnUser (){
        return "{id:" + Integer.toString(id) + ",age:" + Integer.toString(age) + ",username:" + username + "}";
    }

}
